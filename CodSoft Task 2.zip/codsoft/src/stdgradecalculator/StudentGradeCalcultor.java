package stdgradecalculator;
import java.util.Scanner;
public class StudentGradeCalcultor 
{
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Student Grade Calculator");

        System.out.print("Enter the number of subjects: ");
        int numSubjects = scanner.nextInt();

        int totalMarks = 0;
        int maxMarksPerSubject = 100; 
        
        for (int i = 1; i <= numSubjects; i++) {
            System.out.print("Enter Subjects Markds " + i + ": ");
            int marks = scanner.nextInt();
            if (marks < 0 || marks > maxMarksPerSubject) {
                System.out.println("Invalid marks. Marks should be between 0 and " + maxMarksPerSubject);
                i--; 
            } else {
                totalMarks += marks;
            }
        }

       double average = (double) totalMarks / numSubjects;
       double percentage = (average / maxMarksPerSubject) * 100;

    char grade;
        if (average >= 90) 
        {
            grade = 'A';
        } else if (average >= 80) 
        {
            grade = 'B';
        } else if (average >= 70) 
        {
            grade = 'C';
        } else if (average >= 60) 
        {
            grade = 'D';
        } else {
            grade = 'F';
        }

        
        System.out.println("\nResult:");
        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Average Percentage: " + percentage + "%");
        System.out.println("Grade: " + grade);

    }
}
