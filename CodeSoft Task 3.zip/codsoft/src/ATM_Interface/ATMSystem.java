package ATM_Interface;
import java.util.Scanner;
public class ATMSystem 
{
    double balance;
    String accountNumber;
    String pin;

    public ATMSystem(String accountNumber, String pin, double initialBalance) {
        this.accountNumber = accountNumber;
        this.pin = pin;
        this.balance = initialBalance;
    }

    public void displayMenu() 
    {
        System.out.println("ATM Operation:");
        System.out.println("1. Check Balance");
        System.out.println("2. Withdraw Cash");
        System.out.println("3. Deposit Money");
        System.out.println("4. Exit");
    }

    public void checkBalance() 
    {
        System.out.println("Your balance is: $" + balance);
    }

    public void withdrawCash(double amount) 
    {
        if (amount > 0 && amount <= balance) 
        {
            balance -= amount;
            System.out.println("Withdrawal successful. Remaining balance: $" + balance);
        } 
        else
        {
            System.out.println("Invalid amount or insufficient Balance");
        }
    }

    public void depositFunds(double amount) 
    {
        if (amount > 0) 
        {
            balance += amount;
            System.out.println("Deposit successful. New balance: $" + balance);
        } else 
        {
            System.out.println("Invalid amount for deposit");
        }
    }

    public static void main(String[] args) 
    {
        ATMSystem atm = new ATMSystem("123456789", "1234", 15000.0);

        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the ATM System");
        System.out.print("Enter your account number: ");
        String enteredAccountNumber = scanner.nextLine();

        System.out.print("Enter your PIN: ");
        String enteredPin = scanner.nextLine();

        if (enteredAccountNumber.equals(atm.accountNumber) && enteredPin.equals(atm.pin)) 
        {
            int choice;
            do {
                atm.displayMenu();
                System.out.print("Enter your choice (1-4): ");
                choice = scanner.nextInt();

                switch (choice)
                {
                    case 1:
                        atm.checkBalance();
                        break;
                    case 2:
                        System.out.print("Enter withdrawal amount: $");
                        double withdrawAmount = scanner.nextDouble();
                        atm.withdrawCash(withdrawAmount);
                        break;
                    case 3:
                        System.out.print("Enter deposit amount: $");
                        double depositAmount = scanner.nextDouble();
                        atm.depositFunds(depositAmount);
                        break;
                    case 4:
                        System.out.println("Exiting. Thank you!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                        break;
                }

            } while (choice != 4);
        } 
        else
        {
            System.out.println("Invalid account number or PIN.");
        }

    }
}
