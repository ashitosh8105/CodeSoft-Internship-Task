package NumberGame;
import java.util.Scanner;

public class NGame 
{ 

	    public static void main(String[] args) {
	        System.out.println("Welcome to the Number Guessing Game!");
	        System.out.println("I have selected a number between 1 and 100.");

	        int randomNumber = (int) (Math.random() * 100) + 1;
	        int userGuess;
	        int attempts = 0;
	        Scanner scanner = new Scanner(System.in);

	        do {
	            System.out.print("Enter your guess: ");
	            
	            userGuess = scanner.nextInt();
	            
	            attempts++;
	            if (userGuess == randomNumber) {
	                System.out.println("Congratulations! You guessed the correct number in " + attempts + " attempts.");
	            } else if (userGuess < randomNumber) {
	                System.out.println("Try again. The correct number is higher.");
	            } else {
	                System.out.println("Try again. The correct number is lower.");
	            }

	        } while (userGuess != randomNumber);
	    }
	}



